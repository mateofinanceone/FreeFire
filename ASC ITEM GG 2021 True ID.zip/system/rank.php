<option value="Bronze">Bronze</option>
<option value="Silver">Silver</option>
<option value="Gold">Gold</option>
<option value="Platinum">Platinum</option>
<option value="Diamond">Diamond</option>
<option value="Heroic">Heroic</option>
<option value="Grandmaster">Grandmaster</option>