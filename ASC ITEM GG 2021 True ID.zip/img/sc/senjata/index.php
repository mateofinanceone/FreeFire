//Kan Dah Gwe Bilang Ngapain Kesini Bego:v
//Yhaaa Wahyu Awowkoksok Konsollll 

//“Janganlah salah seorang dari kalian mengambil barang saudaranya, tidak dengan main-main tidak pula sungguhan, barangsiapa mengambil tongkat saudaranya hendaklah ia mengembalikannya.” Hasan: [Shahiih al-Jaami’ish Shaghiir (no. 7578)], Sunan Abi Dawud (XIII/346, no. 4982) dan ini adalah lafazhnya, Sunan at-Tirmidzi (III/313, no. 2249).