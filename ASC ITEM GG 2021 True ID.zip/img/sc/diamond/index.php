//Tau Kontol Ga?
//Dasar Kang Maling SC:V