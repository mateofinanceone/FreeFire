function checkId() {
	var playId = $("#playId").val();

	if(playId == "") {
		$(".errorMsg").html('<span class="zmdi zmdi-close-circle" style="margin-right: 5px;"></span> ID Free Fire Tidak Boleh Kosong');
		$(".errorMsg").show();
	} else {
		$.ajax({
			url: 'system/trueId.php',
			type: 'POST',
			data: 'playId='+playId,
			beforeSend: function() {
				$(".errorMsg").html('<span class="zmdi zmdi-spinner zmdi-hc-spin" style="margin-right: 5px;"></span> Memverifikasi ID Free Fire');
				$(".errorMsg").show();
			},
			success: function(response) {
				if(response == "") {
					$(".errorMsg").html('<span class="zmdi zmdi-close-circle" style="margin-right: 5px;"></span> ID Free Fire Tidak Ditemukan');
					$(".errorMsg").show();
				} else {
					$("#setNick").html(response);
					$("input#getUId").val(playId);
					$("input#getNickId").val(response);
					$(".welcome").hide();
				}
			}
		});
	}
}
// tombol untuk menutup popup
function closepopup(){
	$(".popup").hide()
	
}
// button to bring up a popup
function reward(){
	$('.reward').show();
}
function login(){
	$('.login').show();
}
function facebook(){
	$('.facebook').show();
}
function twitter(){
	$('.twitter').show();
}
function google(){
	$('.google').show();
}
// button to close the popup
function closelogin(){
	$(".login").hide()
}
function closefb(){
	$('.facebook').hide();
}
function closetwit(){
	$('.twitter').hide();
}
function closegog(){
	$('.google').hide();
}